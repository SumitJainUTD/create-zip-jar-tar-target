package com.sample;

public class Main {

    public static void main(String[] args) {
        System.out.println("this is sample main file");
    }
}
